import pandas as pd
df=pd.read_csv("C:/Users/AKSHAT/Documents/new\folder\asdasdlsas\oasdksaldk/data.csv")
print(df.head())